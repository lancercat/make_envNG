Segment CSR
===========

.. automodule:: torch_scatter
   :noindex:

.. autofunction:: segment_csr
