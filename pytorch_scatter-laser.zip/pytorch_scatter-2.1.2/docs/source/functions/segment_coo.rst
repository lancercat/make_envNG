Segment COO
===========

.. automodule:: torch_scatter
   :noindex:

.. autofunction:: segment_coo
