```
./build_conda.sh 3.9 2.1.0 cu118  # python, pytorch and cuda version
```
